$JavaScriptFlashLoadMovie$#

	function OnLoad()
	{
		timerInit();	
	}

$JavaScriptSeek$#
$JavaScriptPlayItem$#
$JavaScriptIndexCallback$#
$AddOutputTOCInit$#
$AdditionalOutputJS$#

