    if( eval( document.embeds["$EmbedName"] ) != undefined ) 
    {
	  swfMovie = document.embeds["$EmbedName"];
	} 
	else 
	{
	  swfMovie = window.document.$ObjectIDName;
	}
		