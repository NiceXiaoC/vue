Camtasia Studio Version 6.0.2 - README.TXT

-----------------------------------------------------------------------------
                        ~ TABLE OF CONTENTS ~
-----------------------------------------------------------------------------
1.  WHAT IS CAMTASIA STUDIO?

2.  SYSTEM REQUIREMENTS

3.  SETUP AND CONFIGURATION
    3.1  Installation Instructions
    3.2  Installed Files
    3.3  Uninstall Instructions

4.  WHAT'S NEW
    4.1  Version History

5.  KNOWN LIMITATIONS

6.  GETTING HELP
    6.1  Using Online Help
    6.2  Camtasia Studio Support

7.  PURCHASING CAMTASIA STUDIO

8.  CONTACT INFORMATION

-----------------------------------------------------------------------------
1.  WHAT IS CAMTASIA STUDIO?
-----------------------------------------------------------------------------

Camtasia Studio is a suite of tools that allow you to record screen activity,
edit and narrate the clips, and publish the finished presentation in many
standard file formats and locations.

Camtasia Studio includes all the tools you need to record, annotate,
and produce your videos:
  o  Camtasia Studio      - Edit and produce videos in standard file formats
  o  Camtasia Recorder    - Make a video of anything on your screen
  o  Camtasia MenuMaker   - Create a CD front end menu for your videos
  o  Camtasia Theater     - Create a web front end menu for your Flash videos
  o  Camtasia Player      - Ensures high quality playback of your AVIs
  o  Camtasia Studio PowerPoint Add-in - Record PowerPoint presentations

-----------------------------------------------------------------------------
2.  SYSTEM REQUIREMENTS
-----------------------------------------------------------------------------

To run Camtasia Studio, your system must meet these specifications:

  o  Microsoft Windows XP or Windows Vista
  o  Microsoft DirectX 9 or later version
  o  1.0 GHz processor minimum ~ Recommended: 3.0 GHz
  o  500 MB RAM minimum ~ Recommended: 2.0 GB
  o  115 MB of hard-disk space for program installation
  o  Camtasia Studio Add-in for PowerPoint requires PowerPoint 2000, 2002,
     2003, or 2007
  o  Production to the Apple iPod/iPod Touch/iPhone format requires Apple
     QuickTime 7.2 or later version

To run Camtasia Player or MenuMaker Player, your system must meet these
specifications:

  o  Microsoft Windows 2000, XP, Vista or later 
  o  300 MHz processor 
  o  64 MB of RAM 

-----------------------------------------------------------------------------
3.  SETUP AND CONFIGURATION
-----------------------------------------------------------------------------

3.1 Installation Instructions
    Double-click the file "camtasia.msi" and follow the on-screen
    instructions.

3.2 Installed Files
    The Camtasia Studio installation program copies the following files to
    the Camtasia Studio install folder on your computer during installation:

    Libraries\*.*               ScreenPad libraries
    Media\MenuMaker\*.*         MenuMaker menu templates
    Media\Recorder\*.*          Media files used in Camtasia Recorder
    Media\Studio\*.*            Media files used in Camtasia Studio
    Media\Theater\*.*           Media files used in Camtasia Theater
    Microsoft.VC90.CRT\*.*      Microsoft runtime libraries
    Microsoft.VC90.MFC\*.*      Microsoft MFC libraries
    Microsoft.VC90.MFCLOC\*.*   Microsoft MFC localization libraries
    Windows Media Profiles\*.*  Default profiles used for WMV output
    14_43260.dll                Real Media DLL
    28_83260.dll                Real Media DLL
    atrc3260.dll                Real Media DLL
    autocam.bat                 Sample command line automation batch file
    avifix.reg                  Reg fix for "AVI class not registered" error
    CamMenuMaker.exe            Camtasia MenuMaker author executable
    CamMenuMakerRes.dll         CamMenuMaker.exe resources
    CamMenuPlayer.exe           Camtasia MenuMaker player executable
    CamPlay.exe                 Camtasia Player executable
    CamPlay.txt                 Instructions for running Camtasia Player
    CamPlayLicense.txt          Camtasia Player License Agreement
    CamRecorder.exe             Camtasia Recorder executable
    CamrecShellExt.dll          CAMREC file extractor shell extension
    Camtasf.dll                 Camtasia for Real File Format plugin
    CamtasiaFilters.dll         Camtasia Studio Direct Show filters
    CamtasiaMenuMaker.chm       Camtasia MenuMaker help file
    CamtasiaOfficeAddin.dll     Camtasia PowerPoint Plug-in
    CamtasiaOfficeAddinRes.dll  CamtasiaOfficeAddin.dll resources
    CamtasiaStudio.chm          Camtasia Studio main help file
    CamtasiaStudio.exe          Camtasia Studio editor executable
    CamtasiaStudioRes.dll       CamtasiaStudio.exe resources
    camtasr.dll                 Camtasia for Real Rendering plugin
    CamtasiaTheater.chm         Camtasia Theater help file
    CamTheater.exe              Camtasia Theater executable
    cook3260.dll                Real Media DLL
    dnet3260.dll                Real Media DLL
    ednt3260.dll                Real Media DLL
    erv33260.dll                Real Media DLL
    espr3260.dll                Real Media DLL
    FilterManager.ini           Used to block bad 3rd party filters
    HowToReg.txt                Instructions for purchasing Camtasia Studio
    lame_dshow.ax               LAME MP3 DirectShow codec used by CS
    lfbmp10n.dll                Graphics Library DLL
    LFcmp10n.dll                Graphics Library DLL
    lfgif10n.dll                Graphics Library DLL
    LFWMF10N.DLL                Graphics Library DLL
    License.txt                 Camtasia Studio License Agreement
    LTDIS10N.dll                Graphics Library DLL
    ltefx10N.dll                Graphics Library DLL
    ltfil10N.DLL                Graphics Library DLL
    ltimg10N.dll                Graphics Library DLL
    ltkrn10N.dll                Graphics Library DLL
    mcaacaenc.dll               MainConcept AAC encoder
    mceaac.ax                   MainConcept AAC encoder DirectShow filter
    mcmp4mux.ax                 MainConcept MP4 multiplexer DirectShow filter
    mcmp4mux.dll                MainConcept MP4 multiplexer
    mcstdh264ve.ax              MainConcept AVC/H.264 DirectShow filter
    mcstdh264vout.001           MainConcept AVC/H.264 wrapper file
    mcstdh264vout.dll           MainConcept AVC/H.264 wrapper file
    msvcp71.dll                 Microsoft runtime library
    msvcr71.dll                 Microsoft runtime library
    pncrt.dll                   Real Media DLL
    pngu3266.dll                Real Media DLL
    pnrs3260.dll                Real Media DLL
    preview.mov                 Preview movie for Quicktime video settings
    qt.conf                     Trolltech qt library
    QtAssistantClient4.dll      Trolltech qt library
    QtCore4.dll                 Trolltech qt library
    QtGui4.dll                  Trolltech qt library
    QtNetwork4.dll              Trolltech qt library
    QtWebKit4.dll               Trolltech qt library
    QtXml4.dll                  Trolltech qt library
    Readme.txt                  This file
    Recovery.exe                Tool to recover from a failed capture session
    Recovery.txt                Instructions on the use of Recovery.exe
    rmbe3260.dll                Real Media DLL
    rmme3260.dll                Real Media DLL
    rnco3260.dll                Real Media DLL
    rv303260.dll                Real Media DLL
    Setup_EnSharpen_Decoder.exe EnSharpen decoder setup (free to distribute)
    Setup_EnSharpen_Decoder.exe.manifest     Manifest file for EnSharpen
    sipr3260.dll                Real Media DLL
    SizerHook.dll               Camtasia Studio sizer hooking
    TimelineCOM.ocx             TechSmith DirectShow timeline module
    tokr3260.dll                Real Media DLL
    TSCC.exe                    TSCC codec installer (free to distribute)
    TSCC.exe.manifest           Manifest file for TSCC
    tsccinst.cab                TSCC web page codec installer (free to use)
    TSCCinst.txt                Instructions for installing the TSCC codec
    TscHelp.exe                 TechSmith Html Help Helper app
    TSCHTMLProducer.dll         Camtasia Studio HTML producer
    TSClame.acm                 LAME MP3 ACM codec used by CS
    TSClame_acm.xml             LAME MP3 ACM codec initialization data
    TSCRec3.dll                 Camtasia Studio recording control
    TSMSIhlp.exe                Microsoft Installer helper app
    xcdsfx32.bin                Zip Library Binary File
    XceedZip.dll                Zip library used with Pack and Show


3.3 Uninstall Instructions
    1. Run the Windows Control Panel.
    2. Open the Add/Remove Programs applet (Programs and Features applet on
       Vista) from Control Panel.
    3. Select Camtasia Studio 6 from the list of applications that can be
       uninstalled by Windows.
    4. Click the Add/Remove button (Uninstall button on Vista) to uninstall
       Camtasia Studio 6.


-----------------------------------------------------------------------------
4.  WHAT'S NEW
-----------------------------------------------------------------------------
4.1 Version history

  v6.0.2  Maintenance Release
   General:
   o  Added back the ability to produce a .FLV file.
   o  Added the ability to set the keyframe interval for .FLV and .MP4 file
      productions.

   Studio:
   o  Fixed an issue that would cause .MP4 production settings to not be
      correctly utilized for productions using PIP video.
   o  Fixed an issue with dropping a transition over an existing transition
      causing a loss of sync between the Video 1 and PIP tracks.
   o  Fixed an issue that could cause quizzes to appear twice during the
      playback.

   PPT Add-in:
   o  Fixed an issue that would cause an audio/video sync issue for some
      recordings with both audio and video.

   Recorder:
   o  Improved error handling.
   o  Improved the recording performance with applications with layered
      windows.

 For a complete product version history, visit http://www.techsmith.com

-----------------------------------------------------------------------------
5.  KNOWN LIMITATIONS
-----------------------------------------------------------------------------
  o  Camtasia Recorder generally cannot capture DVD video displays.
  o  Camtasia Recorder cannot always capture audio from other applications
     (e.g. Windows Media Player) depending on your system's sound card and
     drivers.

     Please see http://support.techsmith.com for the latest information.

-----------------------------------------------------------------------------
6.  GETTING HELP
-----------------------------------------------------------------------------
6.1 Using Online Help

    Camtasia Studio�s online Help is available by selecting Help from
    the menu bar of any application.  Also, many context-sensitive Help
    buttons are found in dialogs throughout Camtasia Studio.

    Select About Camtasia Studio from the Help menu to display version and
    registration information.

6.2 Camtasia Studio Support

    TechSmith is committed to providing a reliable, high-quality product
    that is easy to use.  If you have any problem installing or using
    Camtasia Studio, we want to know about it.

    Please select Support from the Help menu in any Camtasia Studio
    application to contact our TechSupport staff.  You can also contact
    TechSmith by mail, phone, or fax (see CONTACT INFORMATION below).

    You can also browse Frequently Asked Questions and submit questions
    for our TechSupport staff by visiting http://support.techsmith.com.

-----------------------------------------------------------------------------
7.  PURCHASING CAMTASIA STUDIO
-----------------------------------------------------------------------------
    Select Help > Purchase Camtasia Studio to launch the purchase wizard.
    Follow the instructions in the purchase wizard to complete your purchase.

    Please contact TechSmith if you have any questions about purchasing
    Camtasia Studio including special offers and multiple unit purchases
    (see CONTACT INFORMATION below).


-----------------------------------------------------------------------------
8.  CONTACT INFORMATION
-----------------------------------------------------------------------------

    TechSmith Corporation
    2405 Woodlake Drive
    Okemos, MI, 48864 USA

    Phone   : +1.517.381.2300
    Fax     : +1.517.381.2336
    Sales   : http://www.techsmith.com/sales
    Support : http://support.techsmith.com
    Web     : http://www.techsmith.com


(C) 1999-2009 TechSmith Corporation. All Rights Reserved. TechSmith, Camtasia, Camtasia Studio, Dubit, Ensharpen, Enterprise Wide, Morae, Rich Recording Technology, Screencast.com, Smartfocus, Snagit, TSCC, and UserVue are all registered marks of TechSmith Corporation, and Camtasia Relay, Expressshow, and Jing are marks of TechSmith Corporation. All other registered trademarks and trademarks are the property of their respective companies.
